/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab06;
import java.util.Scanner;
import java.util.Stack;
import java.util.InputMismatchException;
import java.util.EmptyStackException;

/**
 *
 * @author MUHAMMAD RAYYAN
 */

public class MenuBasedProgram {
    //Check operator priority
    public static int precedence(char ch){
        if(ch=='+'||ch=='-'){
            return 1;
        }else if(ch=='*'||ch=='/'||ch=='%'){
            return 2;
        }
        return 0;
    }

    //Activity 1: Infix to Postfix
    public static String infixToPostfix(String expression){
        Stack<Character> stack=new Stack<>();
        String result="";
        for(int i=0;i<expression.length();i++){
            char ch=expression.charAt(i);
            if(ch==' '){
                continue;
            }
            if(Character.isLetterOrDigit(ch)){
                result=result+ch+" ";
            }else if(ch=='('){
                stack.push(ch);
            }else if(ch==')'){
                while(stack.peek()!='('){
                    result=result+stack.pop()+" ";
                }
                stack.pop(); //Remove opening bracket
            }else{
                while(!stack.isEmpty()){
                    if(stack.peek()=='('){
                        break;
                    }
                    if(precedence(stack.peek())<precedence(ch)){
                        break;
                    }
                    result=result+stack.pop()+" ";
                }
                stack.push(ch);
            }
        }
        while(!stack.isEmpty()){
            result=result+stack.pop()+" ";
        }
        return result.trim();
    }

    //Activity 2: Postfix to Infix
    public static String postfixToInfix(String expression){
        Stack<String> stack=new Stack<>();
        for(int i=0;i<expression.length();i++){
            char ch=expression.charAt(i);
            if(ch==' '){
                continue;
            }
            if(Character.isLetterOrDigit(ch)){
                stack.push(ch+"");
            }else{
                String second=stack.pop();
                String first=stack.pop();
                String result="("+first+" "+ch+" "+second+")";
                stack.push(result);
            }
        }
        return stack.pop();
    }

    //Activity 3: Infix to Prefix
    public static String infixToPrefix(String expression){
        Stack<Character> stack=new Stack<>();
        String result="";
        //Read from right to left
        for(int i=expression.length()-1;i>=0;i--){
            char ch=expression.charAt(i);
            if(ch==' '){
                continue;
            }
            if(Character.isLetterOrDigit(ch)){
                result=ch+" "+result;
            }else if(ch==')'){
                stack.push(ch);
            }else if(ch=='('){
                while(stack.peek()!=')'){
                    result=stack.pop()+" "+result;
                }
                stack.pop(); //Remove closing bracket
            }else{
                while(!stack.isEmpty()){
                    if(stack.peek()==')'){
                        break;
                    }
                    if(precedence(stack.peek())<=precedence(ch)){
                        break;
                    }
                    result=stack.pop()+" "+result;
                }
                stack.push(ch);
            }
        }
        while(!stack.isEmpty()){
            result=stack.pop()+" "+result;
        }
        return result.trim();
    }

    //Activity 4: Prefix to Postfix
    public static String prefixToPostfix(String expression){
        Stack<String> stack=new Stack<>();
        //Read from right to left
        for(int i=expression.length()-1;i>=0;i--){
            char ch=expression.charAt(i);
            if(ch==' '){
                continue;
            }
            if(Character.isLetterOrDigit(ch)){
                stack.push(ch+"");
            }else{
                String first=stack.pop();
                String second=stack.pop();
                String result=first+" "+second+" "+ch;
                stack.push(result);
            }
        }
        return stack.pop();
    }

    //Activity 5: Prefix to Infix
    public static String prefixToInfix(String expression){
        Stack<String> stack=new Stack<>();
        //Read from right to left
        for(int i=expression.length()-1;i>=0;i--){
            char ch=expression.charAt(i);
            if(ch==' '){
                continue;
            }
            if(Character.isLetterOrDigit(ch)){
                stack.push(ch+"");
            }else{
                String first=stack.pop();
                String second=stack.pop();
                String result="("+first+" "+ch+" "+second+")";
                stack.push(result);
            }
        }
        return stack.pop();
    }

    //Activity 6:Postfix to Prefix
    public static String postfixToPrefix(String expression){
        Stack<String> stack=new Stack<>();
        for(int i=0;i<expression.length();i++){
            char ch=expression.charAt(i);
            if(ch==' '){
                continue;
            }
            if(Character.isLetterOrDigit(ch)){
                stack.push(ch+"");
            }else{
                String second=stack.pop();
                String first=stack.pop();
                String result=ch+" "+first+" "+second;
                stack.push(result);
            }
        }
        return stack.pop();
    }

    //Activity 7: Menu
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        while(true){
            System.out.println("\n===== EXPRESSION CONVERSION =====");
            System.out.println("1. Infix to Postfix");
            System.out.println("2. Postfix to Infix");
            System.out.println("3. Infix to Prefix");
            System.out.println("4. Prefix to Postfix");
            System.out.println("5. Prefix to Infix");
            System.out.println("6. Postfix to Prefix");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            try{
                int choice=input.nextInt();
                input.nextLine(); //Consume leftover Enter
                if(choice==7){
                    System.out.println("Program ended.");
                    break;
                }
                if(choice<1||choice>6){
                    System.out.println("Invalid choice!");
                    continue;
                }
                System.out.print("Enter expression: ");
                String expression=input.nextLine();
                String result="";
                switch(choice){
                    case 1:
                        result=infixToPostfix(expression);
                        break;
                    case 2:
                        result=postfixToInfix(expression);
                        break;
                    case 3:
                        result=infixToPrefix(expression);
                        break;
                    case 4:
                        result=prefixToPostfix(expression);
                        break;
                    case 5:
                        result=prefixToInfix(expression);
                        break;
                    case 6:
                        result=postfixToPrefix(expression);
                        break;
                }
                System.out.println("Original expression: "+expression);
                System.out.println("Converted expression: "+result);
            }catch(InputMismatchException e){
                System.out.println("Please enter a whole number!");
                input.nextLine(); //Clear invalid input
            }catch(EmptyStackException e){
                System.out.println("Invalid expression! Check your selected conversion.");
            }
        }
        input.close();
    }
}