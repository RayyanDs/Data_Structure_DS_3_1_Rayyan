
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.menudrivenbst;

import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class MenuDrivenBST {
    static class Node {
        int data;
        Node left;
        Node right;
        Node(int value) {
            data = value;
            left = null;
            right = null;
        }
    }

    static class BinarySearchTree {
        Node root;
        BinarySearchTree() {
            root = null;
        }
        void insert(int value) {
            root = insertRecursive(root, value);
        }
        Node insertRecursive(Node current, int value) {
            if (current == null) {
                return new Node(value);
            }
            if (value < current.data) {
                current.left = insertRecursive(current.left, value);
            }
            else if (value > current.data) {
                current.right = insertRecursive(current.right, value);
            }
            else {
                System.out.println("Duplicate value! Not inserted.");
            }
            return current;
        }

        boolean search(int value) {
            return searchRecursive(root, value);
        }

        boolean searchRecursive(Node current, int value) {
            if (current == null) {
                return false;
            }
            if (current.data == value) {
                return true;
            }
            if (value < current.data) {
                return searchRecursive(current.left, value);
            }
            else {
                return searchRecursive(current.right, value);
            }
        }

        void inorder(Node current) {
            if (current == null) {
                return;
            }
            inorder(current.left);
            System.out.print(current.data + " ");
            inorder(current.right);
        }

        void preorder(Node current) {
            if (current == null) {
                return;
            }
            System.out.print(current.data + " ");
            preorder(current.left);
            preorder(current.right);
        }

        void postorder(Node current) {
            if (current == null) {
                return;
            }
            postorder(current.left);
            postorder(current.right);
            System.out.print(current.data + " ");
        }

        int findMin() {
            Node current = root;
            while (current.left != null) {
                current = current.left;
            }
            return current.data;
        }

        int findMax() {
            Node current = root;
            while (current.right != null) {
                current = current.right;
            }
            return current.data;
        }

        void delete(int value) {
            root = deleteRecursive(root, value);
        }

        Node deleteRecursive(Node current, int value) {
            if (current == null) {
                return null;
            }
            if (value < current.data) {
                current.left = deleteRecursive(current.left, value);
            }
            else if (value > current.data) {
                current.right = deleteRecursive(current.right, value);
            }
            else {

                if (current.left == null && current.right == null) {
                    return null;
                }
                if (current.left == null) {
                    return current.right;
                }

                if (current.right == null) {
                    return current.left;
                }
                current.data = findMinValue(current.right);
                current.right = deleteRecursive(current.right, current.data);
            }
            return current;
        }

        int findMinValue(Node current) {
            while (current.left != null) {
                current = current.left;
            }
            return current.data;
        }
    }
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        BinarySearchTree bst = new BinarySearchTree();
        int choice;
        do {
            System.out.println("\n===== BINARY SEARCH TREE MENU =====");
            System.out.println("1. Insert Multiple Values");
            System.out.println("2. Search a Value");
            System.out.println("3. Display Traversals");
            System.out.println("4. Find Minimum and Maximum");
            System.out.println("5. Delete a Value");
            System.out.println("6. Exit");

            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            switch (choice) {
               
                case 1:
                    System.out.print("How many values do you want to insert? ");
                    int count = input.nextInt();
                    if (count <= 0) {
                        System.out.println("Please enter a positive number.");
                        break;
                    }
                    for (int i = 1; i <= count; i++) {
                        System.out.print("Enter value " + i + ": ");
                        int value = input.nextInt();
                        bst.insert(value);
                    }
                    System.out.println("Insertion operation completed!");
                    break;
                case 2:
                    if (bst.root == null) {
                        System.out.println("Tree is empty!");
                    }
                    else {
                         System.out.print("Enter value to search: ");
                        int searchValue = input.nextInt();
                        if (bst.search(searchValue)) {
                            System.out.println("Value found in the BST!");
                        }
                        else {
                            System.out.println("Value not found!");
                        }
                    }
                    break;
              
                case 3:
                    if (bst.root == null) {
                        System.out.println("Tree is empty!");
                    }
                    else {
                        System.out.println("\nInorder Traversal:");
                        bst.inorder(bst.root);

                        System.out.println("\nPreorder Traversal:");
                        bst.preorder(bst.root);

                        System.out.println("\nPostorder Traversal:");
                        bst.postorder(bst.root);

                        System.out.println();
                    }

                    break;

                case 4:
                    if (bst.root == null) {
                        System.out.println("Tree is empty!");
                    }
                    else {

                        System.out.println("Minimum Value: " + bst.findMin());
                        System.out.println("Maximum Value: " + bst.findMax());
                    }
                    break;

                case 5:
                    if (bst.root == null) {
                        System.out.println("Tree is empty!");
                    }
                    else {
                        System.out.print("Enter value to delete: ");
                        int deleteValue = input.nextInt();
                        if (bst.search(deleteValue)) {
                            bst.delete(deleteValue);
                            System.out.println("Value deleted successfully!");
                            System.out.println("Updated Inorder Traversal:");
                            bst.inorder(bst.root);
                            System.out.println();
                        }
                        else {
                            System.out.println("Value not found! Cannot delete.");
                        }
                    }
                    break;
                case 6:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 6);
    }
}
