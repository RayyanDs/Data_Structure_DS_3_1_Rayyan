
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bst_construction_and_traversal;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class BST_Construction_And_Traversal {
    static class Node {
        int data;
        Node left;
        Node right;
        Node(int value) {
            data = value;
            left = null;
            right = null;
        }
    }

    static class BinarySearchTree {
        Node root;
        BinarySearchTree() {
            root = null;
        }
        void insert(int value) {
            root = insertRecursive(root, value);
        }
        Node insertRecursive(Node current, int value) {
            if (current == null) {
                return new Node(value);
            }
            if (value < current.data) {
                current.left = insertRecursive(current.left, value);
            }
            else if (value > current.data) {
                current.right = insertRecursive(current.right, value);
            }
            return current;
        }

        void inorder(Node current) {
            if (current == null) {
                return;
            }
            inorder(current.left);
            System.out.print(current.data + " ");
            inorder(current.right);
        }

        void preorder(Node current) {
            if (current == null) {
                return;
            }
            System.out.print(current.data + " ");
            preorder(current.left);
            preorder(current.right);
        }
        void postorder(Node current) {
            if (current == null) {
                return;
            }
            postorder(current.left);
            postorder(current.right);
            System.out.print(current.data + " ");
        }
        int findMin() {
            if (root == null) {
                throw new IllegalStateException("Tree is empty");
            }
            Node current = root;
            while (current.left != null) {
                current = current.left;
            }
            return current.data;
        }
        int findMax() {
            if (root == null) {
                throw new IllegalStateException("Tree is empty");
            }
            Node current = root;
            while (current.right != null) {
                current = current.right;
            }
            return current.data;
        }
    }
    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        bst.insert(45);
        bst.insert(25);
        bst.insert(65);
        bst.insert(15);
        bst.insert(35);
        bst.insert(55);
        bst.insert(75);
        bst.insert(10);
        bst.insert(20);

        System.out.println("Inorder Traversal:");
        bst.inorder(bst.root);

        System.out.println("\nPreorder Traversal:");
        bst.preorder(bst.root);

        System.out.println("\nPostorder Traversal:");
        bst.postorder(bst.root);

        System.out.println("\nMinimum Value: " + bst.findMin());
        System.out.println("Maximum Value: " + bst.findMax());
    }
}
