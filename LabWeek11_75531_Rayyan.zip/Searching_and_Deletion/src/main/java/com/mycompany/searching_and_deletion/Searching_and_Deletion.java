
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.searching_and_deletion;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class Searching_and_Deletion {
    static class Node {
        int data;
        Node left;
        Node right;
        Node(int value) {
            data = value;
            left = null;
            right = null;
        }
    }
    static class BinarySearchTree {
        Node root;
        BinarySearchTree() {
            root = null;
        }
        void insert(int value) {
            root = insertRecursive(root, value);
        }
        Node insertRecursive(Node current, int value) {
            if (current == null) {
                return new Node(value);
            }
            if (value < current.data) {
                current.left = insertRecursive(current.left, value);
            }
            else if (value > current.data) {
                current.right = insertRecursive(current.right, value);
            }
            return current;
        }
        boolean search(int value) {
            return searchRecursive(root, value);
        }
        boolean searchRecursive(Node current, int value) {
            if (current == null) {
                return false;
            }
            if (current.data == value) {
                return true;
            }
            if (value < current.data) {
                return searchRecursive(current.left, value);
            }
            else {
                return searchRecursive(current.right, value);
            }
        }
        void delete(int value) {
            root = deleteRecursive(root, value);
        }
        Node deleteRecursive(Node current, int value) {
            if (current == null) {
                return null;
            }
            if (value < current.data) {
                current.left = deleteRecursive(current.left, value);
            }
            else if (value > current.data) {
                current.right = deleteRecursive(current.right, value);
            }
            else {
                if (current.left == null && current.right == null) {
                    return null;
                }
                if (current.left == null) {
                    return current.right;
                }
                if (current.right == null) {
                    return current.left;
                }
                current.data = findMinValue(current.right);
                current.right = deleteRecursive(current.right, current.data);
            }
            return current;
        }

        int findMinValue(Node current) {
            while (current.left != null) {
                current = current.left;
            }
            return current.data;
        }

        void inorder(Node current) {
            if (current == null) {
                return;
            }
            inorder(current.left);
            System.out.print(current.data + " ");
            inorder(current.right);
        }
    }

    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        bst.insert(45);
        bst.insert(25);
        bst.insert(65);
        bst.insert(15);
        bst.insert(35);
        bst.insert(55);
        bst.insert(75);
        bst.insert(10);
        bst.insert(20);

        System.out.println("Searching for 35: " + bst.search(35));
        System.out.println("Searching for 100: " + bst.search(100));

        System.out.println("\nOriginal Inorder Traversal:");
        bst.inorder(bst.root);

        bst.delete(10);
        System.out.println("\n\nAfter deleting 10:");
        bst.inorder(bst.root);

        bst.delete(25);

        System.out.println("\n\nAfter deleting 25:");
        bst.inorder(bst.root);

        bst.delete(45);
        System.out.println("\n\nAfter deleting 45:");
        bst.inorder(bst.root);

        System.out.println();
    }
}
