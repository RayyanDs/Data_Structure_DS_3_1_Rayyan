
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.student_record_management;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class Student_Record_Management {

    static class Node {
        int id;
        String name;
        Node left;
        Node right;
        Node(int studentId, String studentName) {
            id = studentId;
            name = studentName;
            left = null;
            right = null;
        }
    }

    static class BinarySearchTree {
        Node root;
        BinarySearchTree() {
            root = null;
        }

        void insert(int id, String name) {
            root = insertRecursive(root, id, name);
        }
        Node insertRecursive(Node current, int id, String name) {
            if (current == null) {
                return new Node(id, name);
            }
            if (id < current.id) {
                current.left = insertRecursive(current.left, id, name);
            }
            else if (id > current.id) {
                current.right = insertRecursive(current.right, id, name);
            }
            else {
                System.out.println("Student ID already exists!");
            }
            return current;
        }

        Node search(int id) {
            return searchRecursive(root, id);
        }
        Node searchRecursive(Node current, int id) {
            if (current == null || current.id == id) {
                return current;
            }
            if (id < current.id) {
                return searchRecursive(current.left, id);
            }
            else {
                return searchRecursive(current.right, id);
            }
        }

        void delete(int id) {
            root = deleteRecursive(root, id);
        }
        Node deleteRecursive(Node current, int id) {
            if (current == null) {
                return null;
            }
            if (id < current.id) {
                current.left = deleteRecursive(current.left, id);
            }
            else if (id > current.id) {
                current.right = deleteRecursive(current.right, id);
            }
            else {

                if (current.left == null && current.right == null) {
                    return null;
                }

                if (current.left == null) {
                    return current.right;
                }

                if (current.right == null) {
                    return current.left;
                }
                Node successor = findMin(current.right);
                current.id = successor.id;
                current.name = successor.name;

                current.right = deleteRecursive(current.right, successor.id);
            }
            return current;
        }

        Node findMin(Node current) {
            while (current.left != null) {
                current = current.left;
            }
            return current;
        }

        void inorder(Node current) {
            if (current == null) {
                return;
            }
            inorder(current.left);
            System.out.println("ID: " + current.id + " | Name: " + current.name);
            inorder(current.right);
        }

        int count(Node current) {
            if (current == null) {
                return 0;
            }
            return 1 + count(current.left) + count(current.right);
        }
    }

    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();

        bst.insert(50, "Ali");
        bst.insert(30, "Ahmed");
        bst.insert(70, "Sara");
        bst.insert(20, "Usman");
        bst.insert(40, "Ayesha");
        bst.insert(60, "Hassan");
        bst.insert(80, "Fatima");

        System.out.println("Student Records:");
        bst.inorder(bst.root);

        System.out.println("\nSearching for Student ID 40:");

        Node result = bst.search(40);

        if (result != null) {
            System.out.println("Student Found!");
            System.out.println("ID: " + result.id);
            System.out.println("Name: " + result.name);
        }
        else {
            System.out.println("Student Not Found!");
        }

        System.out.println("\nTotal Students: " + bst.count(bst.root));

        System.out.println("\nDeleting Student ID 30...");
        bst.delete(30);

        System.out.println("\nUpdated Student Records:");
        bst.inorder(bst.root);

        System.out.println("\nTotal Students: " + bst.count(bst.root));
    }
}
