/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.binarysearch;
import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class BinarySearch {
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(int[] arr, int target, int l, int r) {
        if (l <= r) {
            int mid = l + (r - l) / 2;
            if (target == arr[mid]) {
                return mid;
            } else if (target > arr[mid]) {
                return binarySearch(arr, target, mid + 1, r);
            } else {
                return binarySearch(arr, target, l, mid - 1);
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        System.out.println("Enter the size of an array: ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        for(int i =0; i< arr.length;i++){
            arr[i] = rand.nextInt(2000);
            System.out.println(arr[i]);
        }
        Arrays.sort(arr);
       
        System.out.println("Enter a value to search: ");
        int target = sc.nextInt();

        int linearResult = linearSearch(arr, target);
        int binaryResult = binarySearch(arr, target, 0, arr.length - 1);

        System.out.println("Target value: " + target);
        if (linearResult != -1) {
            System.out.println("Linear Search is found at index " + linearResult);
        } else {
            System.out.println("Linear Search is not found");
        }

        if (binaryResult != -1) {
            System.out.println("Binary Search is found at index " + binaryResult);
        } else {
            System.out.println("Binary Search is not found");
        }
    }
}
