/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.lab03_task02_rayyan_75531;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class Lab03_Task02_Rayyan_75531 {

    public static void main(String[] args) {
      
        int[] arrayForMerge = {43, 90, 23, 201, 20, 14};
        int[] arrayForQuick = {28, 91, 12, 51, 16, 20, 42};
        
        System.out.println("MERGE SORT");
        System.out.println("Initial State: ");
        printArray(arrayForMerge);
 
        mergeSort(arrayForMerge, 0, arrayForMerge.length - 1);        
        System.out.println("Final Sorted Array (Merge Sort): ");
        printArray(arrayForMerge);

        System.out.println("QUICK SORT");
        System.out.println("Initial State: ");
        printArray(arrayForQuick);
        
        quickSort(arrayForQuick, 0, arrayForQuick.length - 1);
        System.out.print("Final Sorted Array (Quick Sort): ");
        printArray(arrayForQuick);
    }

    public static void mergeSort(int[] arr, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;

            System.out.println("Splitting subarray: ");
            printSubarray(arr, left, right);
            System.out.println();

            mergeSort(arr, left, mid);     
            mergeSort(arr, mid + 1, right); 

            merge(arr, left, mid, right);  
        }
    }

    private static void merge(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        int[] L = new int[n1];
        int[] R = new int[n2];

        for (int i = 0; i < n1; i++) {
            L[i] = arr[left + i];
        }
        for (int j = 0; j < n2; j++) {
            R[j] = arr[mid + 1 + j];
        }

        System.out.print("Merging parts -> Left: ");
        printArray(L);
        System.out.print("and Right: ");
        printArray(R);
        System.out.println();

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = L[i];
            i++; k++;
        }
        while (j < n2) {
            arr[k] = R[j];
            j++; k++;
        }
        
        System.out.println("Result after merge: ");
        printSubarray(arr, left, right);
        System.out.println();
    }

    public static void quickSort(int[] arr, int low, int high) {
        if (low < high) {
            System.out.println("Processing index range: ");
            printSubarray(arr, low, high);
            System.out.println();
            
            int pi = partition(arr, low, high); 

            quickSort(arr, low, pi - 1); 
            quickSort(arr, pi + 1, high);
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high]; 
        System.out.println("Selected Pivot Value: [" + pivot + "]");
        int i = (low - 1);

        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }


        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        System.out.println("Current Array State after Partition: ");
        printArray(arr);
        System.out.println("Pivot element locked at index location: " + (i + 1));
        
        return i + 1;
    }

    private static void printArray(int[] arr) {
        for (int val : arr) {
            System.out.println(val + " ");
        }
        System.out.println();
    }
    private static void printSubarray(int[]arr,int low, int high){
        for (int i = low; i <= high; i++) {
            System.out.println(arr[i]+" ");
        }
    }
}

