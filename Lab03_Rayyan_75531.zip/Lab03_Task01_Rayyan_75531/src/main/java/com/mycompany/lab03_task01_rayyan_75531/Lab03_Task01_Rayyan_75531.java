/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.lab03_task01_rayyan_75531;

import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class Lab03_Task01_Rayyan_75531 {
    static int[] arr = {2,5,6,8,7,1}; // Activity 1 both parts

    public static int RecursionFactorial(int n) {
        if (n <= 1) {
            return 1;
        }
        return n * RecursionFactorial(n - 1);
    }

    public static void Traversal(int n) {
        if (n >= arr.length) {
            return;
        }
        System.out.print(arr[n] + " ");
        Traversal(n + 1);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number to get its factorial");
        int num = sc.nextInt();

        System.out.println("The factorial of " + num + " is " + RecursionFactorial(num));
        System.out.println("Array elements:");
        Traversal(0);
    }
}