/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask02_rayyan_75531_bonustask;
import java.util.Scanner;
/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask02_Rayyan_75531_BonusTask {

    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
        int[] marks = {78, 65, 92, 55, 84};
        System.out.println("Marks in Array: ");

        for (int i = 0; i < marks.length; i++) {
            System.out.print(marks[i] + " ");
        }

        int max = marks[0];
        int min = marks[0];
        int sum = 0;

        for (int i = 0; i < marks.length; i++) {
            sum += marks[i];
            
            if (marks[i] > max) {
                max = marks[i];
            }

            if (marks[i] < min) {
                min = marks[i];
            }
        }

        double average = (double) sum / marks.length;

        System.out.println("\nMaximum Marks: " + max);
        System.out.println("Minimum Marks: " + min);
        System.out.println("Average Marks: " + average);

        for (int i = 0; i < marks.length - 1; i++) {
            for (int j = 0; j < marks.length - i - 1; j++) {
                if (marks[j] > marks[j + 1]) {
                    int temp = marks[j];
                    marks[j] = marks[j + 1];
                    marks[j + 1] = temp;
                }
            }
        }

        System.out.println("\nSorted Array:");
        for (int i = 0; i < marks.length; i++) {
            System.out.print(marks[i] + " ");
        }

        Node first = new Node(78);
        Node second = new Node(65);
        Node third = new Node(92);
        Node fourth = new Node(55);
        Node fifth = new Node(84);

        first.next = second;
        second.next = third;
        third.next = fourth;
        fourth.next = fifth;

        Node newNode = new Node(70);

        newNode.next = first;
        first = newNode;

        System.out.println("\n\nLinked List after insertion:");
        Node current = first;

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }

        System.out.println("\nEnter marks to delete from Linked List:");
        int delete = sc.nextInt();
        current = first;

        if (current.data == delete) {
            first = first.next;
        } else {
            while (current.next != null && current.next.data != delete) {
                current = current.next;
            }

            if (current.next != null) {
                current.next = current.next.next;
            }
        }

        System.out.println("\nFinal Array:");

        for (int i = 0; i < marks.length; i++) {
            System.out.print(marks[i] + " ");
        }

        System.out.println("\n\nFinal Linked List:");
        current = first;

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
    }
}

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}