 ///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// */
//
package com.mycompany.labtask02_rayyan_75531;
//

///**
// *
// * @author MUHAMMAD RAYYAN
// */
//public class LabTask02_Rayyan_75531 {
public class LabTask02_Rayyan_75531 {

    public static void main(String[] args) {
        int[] arr = {45, 12, 78, 23, 9, 56, 34, 89, 17, 63};

        for (int i = 0; i < arr.length; i++) {
            System.out.println("Index " + i + ": " + arr[i]);
        }
        
        int sum = 0;
        int max = arr[0];
        int min = arr[0];
        
        for(int i = 0; i < arr.length; i++){
            sum+= arr[i];
            if(max < arr[i]){
                max = arr[i];
            }
            if(min > arr[i]){
                min = arr[i];
            }
        }
        
        double average =(double) sum/arr.length;
        
        System.out.println("\n");
        System.out.println("Sum: " + sum);
        System.out.println("Average: " + average);
        System.out.println("Min: " + min);
        System.out.println("Max: " + max);
        
        int index = 3;
        int var = 200;
        int[] newArray = new int[arr.length + 1];

        for (int i = 0; i < index; i++) {
            newArray[i] = arr[i];
        }

        newArray[index] = var;

        for (int i = index; i < arr.length; i++) {
            newArray[i + 1] = arr[i];
        }

        for (int i = 0; i < newArray.length; i++) {
            System.out.println("Index " + i + ": " + newArray[i]);
        }

        int deleteIndex = 2;
        int[] delArr = new int[newArray.length - 1];

        for (int i = 0; i < deleteIndex; i++) {
            delArr[i] = newArray[i];
        }

        for (int i = deleteIndex; i < delArr.length; i++) {
            delArr[i] = newArray[i + 1];
        }
        
        System.out.println("\nAfter deletion of one element of an array: ");
        
        for (int i = 0; i < delArr.length; i++) {
            System.out.println("Index " + i + " : " + delArr[i]);
        }
    }
}
