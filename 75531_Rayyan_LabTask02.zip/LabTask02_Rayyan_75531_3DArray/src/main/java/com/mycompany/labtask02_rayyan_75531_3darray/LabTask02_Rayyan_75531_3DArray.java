/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.labtask02_rayyan_75531_3darray;

import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask02_Rayyan_75531_3DArray {

    public static void main(String[] args) {
        int row, column, layer;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of layers: ");
        layer = sc.nextInt();
        System.out.println("Enter the number of rows: ");
        row = sc.nextInt();
        System.out.println("Enter the number of columns: ");
        column = sc.nextInt();

        int Arr3D[][][] = new int[layer][row][column];

        for (int i = 0; i < layer; i++) {
            for (int j = 0; j < row; j++) {
                for (int k = 0; k < column; k++) {
                    System.out.println("Enter value for the position [" + i + "] [" + j + "] [" + k + "]");
                    Arr3D[i][j][k] = sc.nextInt();

                }
            }
        }
        int max = Arr3D[0][0][0];
        int min = Arr3D[0][0][0];
        int sum = 0;
        for (int i = 0; i < layer; i++) {
            for (int j = 0; j < row; j++) {
                for (int k = 0; k < column; k++) {
                    System.out.println("Position: [" + i + "] [" + j + "] [" + k + "] : " + Arr3D[i][j][k]);
                    sum += Arr3D[i][j][k];
                    if (max < Arr3D[i][j][k]) {
                        max = Arr3D[i][j][k];
                    }
                    if (min > Arr3D[i][j][k]) {
                        min = Arr3D[i][j][k];
                    }
                }
            }
        }
        System.out.println("Sum: " + sum);
        System.out.println("Min: " + min);
        System.out.println("Max: " + max);
        int sumLayer = 0;
        for (int i = 0; i < layer; i++) {
            sumLayer = 0;
            for (int j = 0; j < row; j++) {
                for (int k = 0; k < column; k++) {
                    sumLayer += Arr3D[i][j][k];
                }
            }
            System.out.println("Sum of Layer " + (i + 1) + " : " + sumLayer);
        }
        boolean find = false;
        System.out.println("Enter a value to search from the 3D Array: ");
        int search = sc.nextInt();
        for (int i = 0; i < layer; i++) {
            for (int j = 0; j < row; j++) {
                for (int k = 0; k < column; k++) {
                    if (search == Arr3D[i][j][k]) {
                        System.out.println("The Position of this vlaue is: [" + i + "] [" + j + "] [" + k + "]");
                        find = true;
                        break;
                    }
                }
            }
        }
        if (find) {
            System.out.println("The value is in the array!");
        } else {
            System.out.println("The value is not in the array.");
        }
    }
}
