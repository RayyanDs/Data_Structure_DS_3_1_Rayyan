/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.labtask02_rayyan_75531_2darrays;

import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask02_Rayyan_75531_2DArrays {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter number of rows: ");
        int row = sc.nextInt();
        System.out.println("Enter number of columns: ");
        int column = sc.nextInt();
        int Arr2D[][] = new int[row][column];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                System.out.print("Enter for the position: [" + i + "][" + j + "]: ");
                Arr2D[i][j] = sc.nextInt();
            }
        }

        int sum = 0;
        int max = Arr2D[0][0];
        int min = Arr2D[0][0];

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                System.out.println("Position: [" + i + "][" + j + "]: " + Arr2D[i][j]);
                sum += Arr2D[i][j];
                if (max < Arr2D[i][j]) {
                    max = Arr2D[i][j];
                }
                if (min > Arr2D[i][j]) {
                    min = Arr2D[i][j];
                }
            }
        }

        System.out.println("Sum: " + sum);
        System.out.println("Min: " + min);
        System.out.println("Max: " + max);

        int sumRow = 0;
        int sumColumn = 0;

        for (int i = 0; i < row; i++) {
            sumRow = 0;
            for (int j = 0; j < column; j++) {
                sumRow += Arr2D[i][j];
            }
            System.out.println("Row number " + (i+1)  + " : " + sumRow);
        }

        for (int i = 0; i < column; i++) {
            sumColumn = 0;
            for (int j = 0; j < row; j++) {
                sumColumn += Arr2D[j][i];
            }
            System.out.println("Column number " + (i+1) + " : " + sumColumn);
        }

    }
}
