/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.labtask03_rayyan_75531_singlylinkedlist;
import java.util.Scanner;
/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask03_Rayyan_75531_SinglyLinkedList {

    public static void main(String[] args) {
        Node first = new Node(10);
        Node second = new Node(20);
        Node third = new Node(30);
        Node fourth = new Node(40);
        Node fifth = new Node(50);

        first.next = second;
        second.next = third;
        third.next = fourth;
        fourth.next = fifth;

        Node newNode = new Node(5);
        newNode.next = first;
        first = newNode;

        Node Last = new Node(60);
        Node current = first;

        while (current.next != null) {
            current = current.next;
        }

        current.next = Last;
        current = first;

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }

        Scanner sc = new Scanner(System.in);
        System.out.println("\nEnter value to search: ");
        int search = sc.nextInt();
        boolean found = false;
        current = first;

        while (current != null) {
            if (current.data == search) {
                found = true;
                break;
            }
            current = current.next;
        }

        if (found) {
            System.out.println("Value is present in the list.");
        } else {
            System.out.println("Value is not present in the list.");
        }

        System.out.println("\nEnter value to delete: ");
        int delete = sc.nextInt();

        current = first;

        if (current.data == delete) {
            first = first.next;
        } else {
            while (current.next != null && current.next.data != delete) {
                current = current.next;
            }

            if (current.next != null) {
                current.next = current.next.next;
            }
        }

        System.out.println("\nFinal Linked List: ");
        current = first;

        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
    }
}

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}