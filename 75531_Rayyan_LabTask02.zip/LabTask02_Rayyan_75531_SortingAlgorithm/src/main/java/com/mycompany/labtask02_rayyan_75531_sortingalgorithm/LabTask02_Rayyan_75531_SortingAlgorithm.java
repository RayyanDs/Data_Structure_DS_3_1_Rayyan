/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask02_rayyan_75531_sortingalgorithm;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask02_Rayyan_75531_SortingAlgorithm {

    public static void main(String[] args) {
        int[] arr = {12,41,63,86,34,14};
        int[] arrB = {53,25,85,1,29,14};
        int[] arrC = {99,54,32,86,11,1,23};
        System.out.println("Before Bubble Sorting: ");
        for(int i = 0; i < arr.length; i++){
            System.out.print(arr[i] + " ");
        }
        
        bubbleSort(arr);

        System.out.println("\nAfter Bubble Sorting: ");        
        for(int i = 0; i < arr.length; i++){
            System.out.print(arr[i] + " ");
        }
        
        System.out.println("\nBefore Selection Sorting: ");
        for(int i = 0; i < arrB.length; i++){
            System.out.print(arrB[i] + " ");
        }
        
        selectionSort(arrB);
        
        System.out.println("\nAfter Selection Sorting: ");
        for(int i = 0; i < arrB.length; i++){
            System.out.print(arrB[i] + " ");
        }
        
        System.out.println("\nBefore Insertion Sorting: ");
        for(int i = 0; i < arrC.length; i++){
            System.out.print(arrC[i] + " ");
        }
        
        insertionSort(arrC);
        
        System.out.println("\nAfter Insertion Sorting: ");
        for(int i = 0; i < arrC.length; i++){
            System.out.print(arrC[i] + " ");
        }
    }
    
    public static void bubbleSort(int [] arr){
        for (int i = 0; i < arr.length - 1; i++){
            for(int j = 0;j < arr.length- i - 1; j++){
                if(arr[j] > arr[j+1]){
                    int temp = arr[j];
                    arr[j] =arr[j+1];
                    arr[j+1] = temp;
                }
            }
        }
    }
    
    public static void selectionSort(int[] arrB){
        for (int i = 0; i < arrB.length - 1; i++) {
            int minIndex = i;

            for (int j = i + 1; j < arrB.length; j++) {
                if (arrB[j] < arrB[minIndex]) {
                    minIndex = j;
                }
            }
            int temp = arrB[i];
            arrB[i] = arrB[minIndex];
            arrB[minIndex] = temp;
        }
    }
    
    public static void insertionSort(int[] arrC){
        for(int i = 0; i < arrC.length; i++){
            int key = arrC[i];
            int j = i - 1;
            while (j >= 0 && arrC[j] > key) {
                arrC[j + 1] = arrC[j];
                j--;
            }
            arrC[j + 1] = key;
        }
        
    }
}
