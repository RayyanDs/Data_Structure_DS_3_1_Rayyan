/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labchallenge04;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabChallenge04 {

    public static void main(String[] args) {
        //Lab Task Challenge 04
    /*   class Bank {
           private String acc_holder_name;
           private double balance;

            public Bank(String acc_holder_name, double balance) {
                this.acc_holder_name = acc_holder_name;
                this.balance = balance;
            }
            
            public double getBalance() {
                return balance;
            }
           
            void depositBal(double amount) {
                if(amount <= 0){
                    System.out.println("Amount must be positive");
                    return;
                }
                balance += amount;
                System.out.println("Amount Depositied: " + amount);
            }
            
            void withdraw(double amount){
               if(amount <= 0){
                    System.out.println("Amount must be positive");
                    return;
                }
               balance -= amount;
                System.out.println("Withdrew: " + amount);
            }
       }
       Bank B1 = new Bank("Rayyan",10000);
       B1.depositBal(9000);
        System.out.println(B1.getBalance());
        B1.withdraw(10000);
        System.out.println(B1.getBalance()); */
        
    }
}
