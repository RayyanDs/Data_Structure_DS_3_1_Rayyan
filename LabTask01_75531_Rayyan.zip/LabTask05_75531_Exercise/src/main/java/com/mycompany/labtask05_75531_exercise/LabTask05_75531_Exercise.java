/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask05_75531_exercise;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask05_75531_Exercise {

    public static void main(String[] args) {
        //Activity 1 Lab task 05
     /*int a = 5, b = 2;
     System.out.println(a/b);
     System.out.println((double)a/b); */
     
     //Activity 02
    /* int x = 5;
        System.out.println(x++);
        System.out.println(x);
        System.out.println(++x); */
        
    //Activity 03
   /* int age = 30;
    boolean has_card = true;
    
    if(age>= 21 && has_card){
        System.out.println("Eligible");
    } else{
        System.out.println("Ineligible");
    } */
   
   //Activity 4
   /*double d = 9.9;
   int x = (int)d;
   int y = 10;
   
        System.out.println(x);
        System.out.println(y);
          */
   
   //Exercise 1
   /*int x = 25;
   int y = 252;
   int z = 23;
   float avg = (x+y+z)/3;
        System.out.println(avg); */
   
   //Exercise 2
   /*int x = 12;
        System.out.println(x++);
        System.out.println(x);
        System.out.println(++x); */
   
   //Exercise 3
   /*Scanner sc = new Scanner(System.in);
        System.out.println("Enter your marks");
        int marks = sc.nextInt();
        System.out.println("Enter your Attendence");
        int attendence = sc.nextInt();
    
        if(marks >=50 && attendence >= 75){
            System.out.println("You are eligible");
        }else {
            System.out.println("Inelligible");
        } */
   
   //Exercise 4
   /* double a = 99.95;
   int b = (int)a;
        System.out.println("Double " + a);
        System.out.println("Int: " + b); */
   
    }
}
