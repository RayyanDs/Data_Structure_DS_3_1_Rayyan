/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labchallenge01;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabChallenge01 {

    public static void main(String[] args) {
        //CHALLENGE TASK 01
   
   /* String studentName = "Rayyan";
   int studentID = 75531;
   double cgpa = 4.0;
   char grade = 'A';
   boolean isEnrolled = true;
   
        System.out.println("--------Student Information--------");
        System.out.println("Name: " + studentName);
        System.out.println("ID: " + studentID);
        System.out.println("CGPA: " + cgpa);
        System.out.println("Grade: " + grade);
        System.out.println("Enrolled: " + isEnrolled); */
   
    }
}
