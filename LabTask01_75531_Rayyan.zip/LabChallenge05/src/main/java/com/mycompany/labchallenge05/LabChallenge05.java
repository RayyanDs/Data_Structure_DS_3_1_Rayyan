/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labchallenge05;
import java.util.Scanner;
/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabChallenge05 {

    public static void main(String[] args) {
        //Lab Task Challenge 5
    Scanner sc = new Scanner(System.in);
        System.out.println("Enter marks of the first subject: ");
        double m1 = sc.nextDouble();
        System.out.println("Enter marks of the second subject: ");
        double m2 = sc.nextDouble();
        System.out.println("Enter marks of the third subject: ");
        double m3 = sc.nextDouble();
        
        double sum = m1 + m2 + m3;
        double average = (m1 + m2 + m3)/3;
        if (average >= 40 && (m1 > 33 && m2 >33 && m3 > 33)) {
            System.out.println("You have Passed");
        } else {
            System.out.println("YOu have Failed");
        }
        System.out.println("Average: " + average);
    }
}
