/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask03_75531_exercises;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask03_75531_Exercises {

    public static void main(String[] args) {
/* Lab Task 03
       Activity 01
         */
 /*for (int i = 0; i<5; i++){
           System.out.println(i+1);
       }*/
        //Activity 02
        /*int i = 7;
       do {
           System.out.println(i);
           i++;
       } while(i <=5);
   /*
     
     //Activity 03:
    /* int sum = 0;
     for(int i = 1; i < 10; i++){
        sum = sum + i;
        System.out.println(sum);
     }*/
        //Activity 04:
        /*double[] values = {2.0, 3.5,7.4};
    double sum = 0;
    for (double value: values){
        sum += value;
        System.out.println(sum);
    } */
 /* for (int i = 0; i <10; i++){
        if (i == 3){
            continue;
        }
        if(i==7){
            break;
        }
        System.out.println(i);
      } */
        //Student Exercise 01:
        /* int i = 10;
   while(i >= 1){
       System.out.println(i);
       i--;
   } */
 /* Scanner sc = new Scanner(System.in);
    int num;
    do{
        System.out.println("Enter a positive number:");
        num = sc.nextInt();
     } while(num>0); */
        //Exercise 03:
        /*  Scanner sc = new Scanner(System.in);
   System.out.println("Enter a factorial");
        int n = sc.nextInt();
   int factorial =1;
   for(int i = n; i> 0; i--){
       factorial *= i;
   }
   System.out.println(factorial);
         */
 /*Exercise 4
    int[] arr = {5,34,6,24,99,121};
    int max = arr[0];
    for (int i = 1; i< arr.length; i++){
        if (max < arr[i]){
           max = arr[i];
        }
     }
        System.out.println(max); */
 /*Exercise 5
    for (int i =1;i<=20;i++){
        if (i%3==0){
    
        } else{
            System.out.println(i);
        }
    } */
    }
}
