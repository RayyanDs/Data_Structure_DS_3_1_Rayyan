/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labchallenge02;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabChallenge02 {

    public static void main(String[] args) {
        /* Challenge Task 02
        Scanner sc = new Scanner(System.in);
        double c = 0;
        System.out.println("Choose one of the options");
        System.out.println(" 1.Addition \n 2.Difference \n 3.Multiplication \n 4.Quotient");
        int choice = sc.nextInt();
        
        System.out.println("Enter the first number: ");
        double a = sc.nextDouble();
        System.out.println("Enter the second number: ");
        double b = sc.nextDouble();
        
        switch(choice){
            case 1:
            c = a+b;
            break;
         case 2:
            c = a-b;
            break;
         case 3: 
            c = a*b;
            break;
         case 4:
            c = a/b;
       break;
         default:
            System.out.println("Invalid Option");
        }
        System.out.println("Outcome: " + c); */
       
    }
}
