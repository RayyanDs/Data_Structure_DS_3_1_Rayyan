/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask04_75531_exercise;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask04_75531_Exercise {

    public static void main(String[] args) {
        /*Lab Task 04
    Activity 01 & 02 & 03 */
    /*    class Counter {
            private int count;
            
            public Counter() {
                count = 0;
            }

            public Counter(int count) {
                this.count = count;
            }

            public int getCount() {
                return count;
            }
            public void incrementCount(){
                count++;
            }
            public void decrementCount(){
                count--;
            }
        }
        Counter c1 = new Counter();
        c1.incrementCount();
        System.out.println(c1.getCount()); 
        c1.decrementCount();
        c1.decrementCount();
        System.out.println(c1.getCount()); */
      /*  class Book {

            String title;
            String author;
            double price;

            public Book(String title, String author, double price) {
                this.title = title;
                this.author = author;
                this.price = price;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public void setAuthor(String author) {
                this.author = author;
            }

            public void setPrice(double price) {
                this.price = price;
            }

            public String getTitle() {
                return title;
            }

            public String getAuthor() {
                return author;
            }

            public double getPrice() {
                return price;
            }
            
        }
        Book B1 = new Book("The Wonders","williams",987.99);
        Book B2 = new Book("Forgotten Hills","James", 999.99);

        System.out.println(B1.getAuthor());
        System.out.println(B2.getAuthor()); */
     /* class Rectangle {
          double width, height;

            public double getWidth() {
                return width;
            }

            public double getHeight() {
                return height;
            }

            public void setWidth(double width) {
                this.width = width;
            }

            public void setHeight(double height) {
                this.height = height;
            }

            public Rectangle(double width, double height) {
                this.width = width;
                this.height = height;
            }
            public double Area(double width,double height){
                return (height * width);
            }
            
            public double Perimeter(double width,double height){
                return ((2*height) * (2*width));
            }
      }
      Rectangle R1 = new Rectangle(10,20);
      System.out.println(R1.Area(15, 20));
      System.out.println(R1.Perimeter(15, 20)); */
    
     
    }
}
