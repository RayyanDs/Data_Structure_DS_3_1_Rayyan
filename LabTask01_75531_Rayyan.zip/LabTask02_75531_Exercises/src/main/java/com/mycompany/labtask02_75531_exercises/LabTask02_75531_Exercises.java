/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labtask02_75531_exercises;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask02_75531_Exercises {

    public static void main(String[] args) {
        /*Lab Task 02
     Activity 01 */
 /* Scanner sc = new Scanner(System.in);
     System.out.println("enter your marks: ");
     int marks = sc.nextInt();
     System.out.println("Your marks are " + marks); */
        // activity 02:
        /*  int marks = 85;
     
        if (marks >=85){
            System.out.println("Grade = A");
        } else if (marks >=75){
            System.out.println("Grade = B");
        }
        else if (marks >=65){
            System.out.println("Grade = C");
        }else if (marks >= 55){
            System.out.println("Grade = D");
        } else {
            System.out.println("You have Failed.");
        }*/
        //Activity 03:
        /*Scanner sc = new Scanner (System.in);
      System.out.println("choose from one of the following options: ");
      System.out.println("1. Insert \n2. Delete");
      int choice = sc.nextInt();
      
      switch(choice){
          case 1:
              System.out.println("Insert");
              break;
          case 2:
              System.out.println("Delete");
              break;
          default:
              System.out.println("Invalid");
      } */
        //exercise 01:
        /*  Scanner sc = new Scanner(System.in);
        System.out.println("Enter two numbers: ");
        int a = sc.nextInt();
        int b = sc.nextInt();

        if (a > b) {
            System.out.println("a is greater than b");
        } else {
            System.out.println("b is greater than a");
        } */
 /*Exercise 2
        Scanner sc = new Scanner(System.in);
      System.out.println("Enter the marks of the student: ");
      int marks = sc.nextInt();
      System.out.println("Enter the attendance of the student: ");
      int attendence = sc.nextInt();
      
      if (marks >= 50 && attendence >= 50){
          System.out.println("You are eligible");
      } else {
          System.out.println("You are not eligible");
      } */
        //Exercise 03 & 04:
        /* Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of day in the week: ");
        int day = sc.nextInt();

        switch (day) {
            case 1:
                System.out.println("Today is Monday.");
                break;
            case 2:
                System.out.println("Today is Tuesday.");
                break;
            case 3:
                System.out.println("Today is Wednesday.");
                break;
            case 4:
                System.out.println("Today is Thursday.");
                break;
            case 5:
                System.out.println("Today is Friday.");
                break;
            case 6:
                System.out.println("Today is Saturday.");
                break;
            case 7:
                System.out.println("Today is Sunday.");
                break;
            default:
                System.out.println("Enter a valid choice.");
        } */
    }
}
