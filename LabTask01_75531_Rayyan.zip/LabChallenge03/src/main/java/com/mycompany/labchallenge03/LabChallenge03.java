/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labchallenge03;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabChallenge03 {

    public static void main(String[] args) {
        //Lab Task Challenge 3
       /* Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of courses: ");
        int n = sc.nextInt();
        
        int[] marks = new int[n];
        int sum = 0;
        
        for(int i = 0; i <n; i++){
            System.out.println("Enter marks of course " + i+1 + ": ");
            marks[i] = sc.nextInt();
            sum += marks[i];
        }
        
        int max = marks[0];
        int countPassed = 0;
        
        for(int mark : marks) {
            if (mark > max){
                max = mark;
            }
            if(mark >= 50){
                countPassed++;
            }
        }
        System.out.println("--------Results--------");
        System.out.println("Sum of marks: " + sum);
        System.out.println("Maximum marks: " + max);
        System.out.println("Number of subjects passed: " + countPassed); */
       

    }
}
