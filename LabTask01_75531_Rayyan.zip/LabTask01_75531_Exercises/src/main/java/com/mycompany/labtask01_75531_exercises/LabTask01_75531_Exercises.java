/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.labtask01_75531_exercises;
import java.util.Scanner;

/**
 *
 * @author MUHAMMAD RAYYAN
 */
public class LabTask01_75531_Exercises {

    public static void main(String[] args) {
        /* Activity 1
        System.out.println("Welcome to Data Structures Lab!");
         
        Activity 2
        int age = 18;
        double cgpa = 4.0;
        String name = "Rayyan";
        boolean passed = true;

        System.out.println(name);
        System.out.println(age);
        System.out.println(cgpa);
        System.out.println(passed);
        
        Activity 3
        int x = 10;
        x = x + 5;
        x++;
        System.out.println(x); 
         
        Exercise 1
        String name = "Rayyan";
        int semesterNum = 3;
        double cgpa = 4.0;

        System.out.println(name);
        System.out.println(semesterNum);
        System.out.println(cgpa);
        
        Exercise 2 
        int a = 120;
        int b = 60;

        System.out.println(a - b);
        System.out.println(a + b);
        System.out.println(a * b);
        System.out.println(a / b); 
        
        Student Exercise 3:
        /*  String StudentName = "Rayyan";
        int StudentAge = 18;
        double StudentCGPA = 4.0;
        int StudentID = 75531;
        String StudentGender = "Male";
        
        System.out.println(StudentName);
        System.out.println(StudentAge);
        System.out.println(StudentCGPA);
        System.out.println(StudentID);
        System.out.println(StudentGender);
         */

        //Activity 01, Exercise 04:
        /* int age = 3;
      System.out.println(age);
         */

    }
}
